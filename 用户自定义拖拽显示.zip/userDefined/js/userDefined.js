	var tbodyArr = [
		{
			number:"1",
			name:"小鲸鱼",
			sex:"女",
			html:"熟练",
			css:"熟练",
			js:"熟练",
			jq:"熟练",
			vue:"熟练",
			wxgzh:"熟练",
			angular:"熟练",
			es:"熟练",
			ajax:"熟练",
			wx:"熟练",
			hunhe:"熟练",
			webpack:"熟练",
			bootstrap:"熟练",
			wxxcx:"熟练",
			ps:"良好",
			sql:"一般",
			java:"一般"
		},
		{
			number:"2",
			name:"小乌龟",
			sex:"女",
			html:"熟练",
			css:"熟练",
			js:"熟练",
			jq:"熟练",
			vue:"熟练",
			wxgzh:"熟练",
			angular:"熟练",
			es:"熟练",
			ajax:"熟练",
			wx:"熟练",
			hunhe:"熟练",
			webpack:"熟练",
			bootstrap:"熟练",
			wxxcx:"熟练",
			ps:"良好",
			sql:"一般",
			java:"一般"
		},{
			number:"3",
			name:"毛毛",
			sex:"男",
			html:"熟练",
			css:"熟练",
			js:"熟练",
			jq:"熟练",
			vue:"熟练",
			wxgzh:"熟练",
			angular:"熟练",
			es:"熟练",
			ajax:"熟练",
			wx:"熟练",
			hunhe:"熟练",
			webpack:"熟练",
			bootstrap:"熟练",
			wxxcx:"熟练",
			ps:"良好",
			sql:"一般",
			java:"一般"
		}
	];
	var data = {
		"detail":{
			"dataList": [
				{
					"fileldKey":"number",
					"fileldNo":1,
					"fileldValue":"序号",
					"isCheck":true
				},
				{
					"fileldKey":"name",
					"fileldNo":2,
					"fileldValue":"姓名",
					"isCheck":true
				},
				{
					fileldKey:"sex",
					fileldNo:3,
					fileldValue:"性别",
					isCheck:true
				},
				{
					fileldKey:"html",
					fileldNo:4,
					fileldValue:"HTML5",
					isCheck:true
				},
				{
					fileldKey:"css",
					fileldNo:5,
					fileldValue:"CSS3",
					isCheck:true
				},
				{
					fileldKey:"js",
					fileldNo:6,
					fileldValue:"JavaScript",
					isCheck:true
				},
				{
					fileldKey:"jq",
					fileldNo:7,
					fileldValue:"JQuery",
					isCheck:true
				},
				{
					fileldKey:"vue",
					fileldNo:8,
					fileldValue:"VUE.js",
					isCheck:true
				},
				{
					fileldKey:"wxgzh",
					fileldNo:9,
					fileldValue:"公众号开发",
					isCheck:true
				},
				{
					fileldKey:"angular",
					fileldNo:10,
					fileldValue:"Angular.js",
					isCheck:true
				},
				{
					fileldKey:"es",
					fileldNo:11,
					fileldValue:"ES6",
					isCheck:true
				},
				{
					fileldKey:"ajax",
					fileldNo:12,
					fileldValue:"Ajax",
					isCheck:true
				},
				{
					fileldKey:"wx",
					fileldNo:13,
					fileldValue:"微信二次开发",
					isCheck:true
				},
				{
					fileldKey:"hunhe",
					fileldNo:14,
					fileldValue:"混合开发",
					isCheck:true
				},
				{
					fileldKey:"webpack",
					fileldNo:15,
					fileldValue:"webpack",
					isCheck:true
				},
				{
					fileldKey:"bootstrap",
					fileldNo:16,
					fileldValue:"bootstrap",
					isCheck:true
				},
				{
					fileldKey:"wxxcx",
					fileldNo:17,
					fileldValue:"小程序开发",
					isCheck:true
				},
				{
					fileldKey:"ps",
					fileldNo:18,
					fileldValue:"PhotoShop",
					isCheck:true
				},
				{
					fileldKey:"sql",
					fileldNo:19,
					fileldValue:"SQL删库到跑路",
					isCheck:true
				},
				{
					fileldKey:"java",
					fileldNo:20,
					fileldValue:"JAVA面向对象",
					isCheck:true
				}
			]
		}
	}
	
	showDefined();//显示页面上的数据
	function showDefined(){
		var showBody = [];
		var showHead = [];
		for(var i = 0;i<data.detail.dataList.length;i++){
			if(data.detail.dataList[i].isCheck == 1){
				showHead.push(data.detail.dataList[i].fileldValue);
				showBody.push(data.detail.dataList[i].fileldKey);
			}
		}
		if(showBody.length == data.detail.dataList.length){
			$("#userCheckbox").attr("checked","true");
		}
		//渲染head
		var headHtml = '<tr role="row">';
		for(var i = 0;i<showHead.length;i++){
			headHtml += '<th class="distext center">'+showHead[i]+'</th>';
		}
		headHtml+="</tr>";
		$("#definedTable thead").html(headHtml);

		//渲染body
		var bodyHtml = "";
		for(var i = 0;i<tbodyArr.length;i++){
			var num = i+1;
			bodyHtml += '<tr data_id="'+i+'">';
			for(var j = 0;j<showBody.length;j++){
				bodyHtml += '<td>'+tbodyArr[i][showBody[j]]+'</td>';
			}
			bodyHtml += '</tr>';
		}
		$("#definedTable tbody").html(bodyHtml);
		var html = template.render('userDefinedGen', data);
		$("#userDefinedModal").html(html);
		//初始化拖拽的方法
		divs = document.querySelectorAll('.segmentBody');
		[].forEach.call(divs, function(d) {
		    d.addEventListener('dragstart', handleDragStart, false);
		    d.addEventListener('dragenter', handleDragEnter, false);
		    d.addEventListener('dragover', handleDragOver, false);
		    d.addEventListener('dragleave', handleDragLeave, false);
		    d.addEventListener('drop', handleDrop, false);
		    d.addEventListener('dragend', handleDragEnd, false);
		});
	}

	function showNewHtml(){
		var newUserDefinedList = [];
	    $("#userDefinedModal div").each(function(index, el) {
	     	var obj = {
	     		"fileldValue": $(el).find('span').eq(0).html(),
				"fileldKey": $(el).find('span').eq(1).html(),
				"fileldNo":index+1,
				"isCheck":$(el).hasClass('active')?1:0
	     	}
	     	newUserDefinedList.push(obj);
	    });
	    
	    //重新把页面上所有的已选中的div复制check=1
		var fileldValueList = [];
		$("#userDefinedModal .active").each(function(index, el) {
			fileldValueList.push($(el).find('span').eq(0).html());
		});
		for(let i = 0;i < newUserDefinedList.length;i++){
			for(let j = 0;j<fileldValueList.length;j++){
				if(fileldValueList[j] == newUserDefinedList[i].fileldValue){
					newUserDefinedList[i].isCheck = 1;
				}
			}
		}
		data.detail.dataList = newUserDefinedList;
		showDefined();//重新显示页面上的dom
	}
	

	$("#userDefinedModal ").on("click",'i[name="yes"]',function(){
		if($(this).parent().hasClass('active')){
			$(this).parent().removeClass('active');
			$(this).removeClass('glyphicon-ok yes');
			$(this).addClass('glyphicon-remove closed');
			for(let i = 0;i<data.detail.dataList.length;i++){
				if($(this).parent().find('span').eq(0).html() == data.detail.dataList[i].fileldValue){
					data.detail.dataList[i].isCheck = 0;
				}
			}
			$("#userCheckbox").removeAttr("checked");//移除复选框选中
		}else{
			$(this).parent().addClass('active');
			$(this).removeClass('glyphicon-remove closed');
			$(this).addClass('glyphicon-ok yes');
			let checkList = [];
			for(let i = 0;i<data.detail.dataList.length;i++){
				if($(this).parent().find('span').eq(0).html() == data.detail.dataList[i].fileldValue){
					data.detail.dataList[i].isCheck = 1;
				}
				if(data.detail.dataList[i].isCheck == 1){
					checkList.push(data.detail.dataList[i]);
				}
			}
			//判断是否全选，让全选的复选框选中
			if(checkList.length == data.detail.dataList.length){
				$("#userCheckbox").attr("checked","true");
			}
		}
		showDefined();
	});


	$("#userDefinedModal ").on("click",'i[name="closed"]',function(){
		if($(this).parent().hasClass('active')){
			$(this).parent().removeClass('active');
			$(this).removeClass('glyphicon-ok yes');
			$(this).addClass('glyphicon-remove closed');
			for(let i = 0;i<data.detail.dataList.length;i++){
				if($(this).parent().find('span').eq(0).html() == data.detail.dataList[i].fileldValue){
					data.detail.dataList[i].isCheck = 0;
				}
			}
			$("#userCheckbox").removeAttr("checked");
		}else{
			$(this).parent().addClass('active');
			$(this).removeClass('glyphicon-remove closed');
			$(this).addClass('glyphicon-ok yes');
			let checkList = [];
			for(let i = 0;i<data.detail.dataList.length;i++){
				if($(this).parent().find('span').eq(0).html() == data.detail.dataList[i].fileldValue){
					data.detail.dataList[i].isCheck = 1;
				}
				if(data.detail.dataList[i].isCheck == 1){
					checkList.push(data.detail.dataList[i]);
				}
			}
			if(checkList.length == data.detail.dataList.length){
				$("#userCheckbox").attr("checked","true");
			}
		}
		showDefined();
	});
	//全选
	$("#userCheckbox").on("click",function(){
		if($(this).is(':checked') == true){
			$("#userDefinedModal .segmentBody").each(function(index, el) {
				$(el).addClass('active');
				$(el).find("i").addClass('yes glyphicon-ok');
				$(el).find("i").removeClass('closed glyphicon-remove');
			});
			for(let i = 0;i<data.detail.dataList.length;i++){
				data.detail.dataList[i].isCheck = 1;
			}
		}else{
			$("#userDefinedModal .segmentBody").each(function(index, el) {
				$(el).removeClass('active');
				$(el).find("i").removeClass('yes glyphicon-ok');
				$(el).find("i").addClass('closed glyphicon-remove');
			});
			for(let i = 0;i<data.detail.dataList.length;i++){
				data.detail.dataList[i].isCheck = 0;
			}
		}
		showDefined();
	});
	//以下是拖拽的方法
	function handleDragStart(e) {
	    this.style.opacity = '1';
	    dragSrcEl = this;
	    e.dataTransfer.effectAllowed = 'move';
	    e.dataTransfer.setData('text/html', this.innerHTML);
	}
  	function handleDragEnter(e) {
     	this.classList.add('over');
  	}
  	function handleDragLeave(e) {
     	this.classList.remove('over');
  	}

	function handleDragOver(e) {
	    if (e.preventDefault) {
	        e.preventDefault();
	    }
	    return false;
	}
	//拖拽完成后，作用在拖拽元素上
	function handleDrop(e) {
	    if (dragSrcEl != this) {
	        dragSrcEl.innerHTML = this.innerHTML;
	        if($(this).hasClass('active') && $(dragSrcEl).hasClass('active')){
	            //$(dragSrcEl).addClass('active');
	            //$(this).addClass('active');
	        }else if(!$(this).hasClass('active') && !$(dragSrcEl).hasClass('active')){
	            //$(dragSrcEl).removeClass('active');
	            //$(this).removeClass('active');
	        }else if($(this).hasClass('active')){
	            $(dragSrcEl).addClass('active');
	            $(this).removeClass('active');
	        }else{
	            $(dragSrcEl).removeClass('active');
	            $(this).addClass('active');
	        }
	        this.innerHTML = e.dataTransfer.getData('text/html');
	    }
	    return false;
	}
	//拖拽完成后，作用在被拖拽元素上
	function handleDragEnd(e) {
	    this.style.opacity = '1';
	    [].forEach.call(divs, function(d) {
	        d.classList.remove('over');
	        showNewHtml();
	    });
	}
